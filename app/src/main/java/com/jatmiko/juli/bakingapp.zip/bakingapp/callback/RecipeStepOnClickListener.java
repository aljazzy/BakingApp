package com.jatmiko.juli.bakingapp.callback;

/**
 * Created by Miko on 09/10/2017.
 */

public interface RecipeStepOnClickListener {
    void onStepSelected(int selectedPosition);
}
