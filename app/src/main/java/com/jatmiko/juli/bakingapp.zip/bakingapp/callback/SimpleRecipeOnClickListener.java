package com.jatmiko.juli.bakingapp.callback;

import com.jatmiko.juli.bakingapp.model.Recipe;

/**
 * Created by Miko on 18/10/2017.
 */

public interface SimpleRecipeOnClickListener {
    void onRecipeSelected(Recipe recipe);
}
