package com.jatmiko.juli.bakingapp.callback;

import com.jatmiko.juli.bakingapp.model.Recipe;

/**
 * Created by Miko on 09/10/2017.
 */

public interface RecipeOnClickListener {
    void onRecipeSelected(Recipe recipe);
}
